# Running Unit Tests of Lovefield

## Manual Testing

Lovefield has two different set of unit tests: SPAC and lib. The SPAC tests are written in Jasmine and shall be tested via node.js; the lib tests are written in JUnit and needs to run a test server.

tools/run_test_server.js provides a test server that can be used to host either normal unit tests or the performance tests. Please run it to see the usage.

TBA: SPAC test steps

## Automatic Testing

TBA
