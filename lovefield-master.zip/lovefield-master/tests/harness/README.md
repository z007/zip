# Test Harness for Lovefield

Harness tests under sqlite/ are hand ported from [SQLite tests](
http://www.sqlite.org/cgi/src/dir?ci=c298ea0bd90d6367&name=test). They share
the same name with their sqlite ancestor.

Other harness tests may be added in the future.
